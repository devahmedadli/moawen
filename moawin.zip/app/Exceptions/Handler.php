<?php

namespace App\Exceptions;

use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Illuminate\Http\Request;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Validation\ValidationException;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\MethodNotAllowedHttpException;
use Throwable;

class Handler extends ExceptionHandler
{
    /**
     * Register the exception handling callbacks for the application.
     */
    public function register(): void
    {
        $this->renderable(function (Throwable $e, Request $request) {
            if ($request->is('api/*') || $request->wantsJson()) {
                $response = [
                    'success' => false,
                    'message' => 'Internal Server Error',
                ];

                // Handle different exception types
                switch(true) {
                    case $e instanceof ValidationException:
                        return response()->json([
                            'success' => false,
                            'message' => 'Validation Error',
                            'errors' => $e->errors(),
                        ], 422);

                    case $e instanceof AuthenticationException:
                        return response()->json([
                            'success' => false,
                            'message' => 'Unauthenticated',
                        ], 401);

                    case $e instanceof ModelNotFoundException:
                        return response()->json([
                            'success' => false,
                            'message' => 'Resource not found',
                        ], 404);

                    case $e instanceof NotFoundHttpException:
                        return response()->json([
                            'success' => false,
                            'message' => 'The requested URL was not found',
                        ], 404);

                    case $e instanceof MethodNotAllowedHttpException:
                        return response()->json([
                            'success' => false,
                            'message' => 'Method not allowed',
                        ], 405);

                    default:
                        $response['message'] = $e->getMessage();
                        
                        if (config('app.debug')) {
                            $response['debug'] = [
                                'message' => $e->getMessage(),
                                'file' => $e->getFile(),
                                'line' => $e->getLine(),
                                'trace' => $e->getTraceAsString()
                            ];
                        }

                        return response()->json($response, 500);
                }
            }
        });
    }
}
