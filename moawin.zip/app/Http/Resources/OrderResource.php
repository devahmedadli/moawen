<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class OrderResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id'            => $this->id,
            'buyer_id'      => $this->buyer_id,
            'seller_id'     => $this->seller_id,
            'service_id'    => $this->service_id,
            'delivery_date' => $this->delivery_date,
            'total_amount'  => $this->total_amount,
            'rating_given'  => $this->rating_given,
            'status'        => $this->status,
            'created_at'    => $this->created_at,
            'updated_at'    => $this->updated_at,
        ];
    }
}
