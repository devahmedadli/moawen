<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ServiceResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed> 
     * 
     */

    public function toArray(Request $request): array
    {
        
        $allInfo = $request->get('all_info') == 'true';
        
        return [
            'id'            => $this->id,
            'name'          => $this->name,
            'description'   => $this->description,
            'price'         => (int) $this->price,
            'delivery_time' => $this->when($allInfo, $this->delivery_time),
            'response_time' => $this->when($allInfo, $this->response_time),
            'service_level' => $this->when($allInfo, $this->service_level),
            'image'         => $this->thumbnail_url,
            'tags'          => $this->when($allInfo, $this->tags),
            'status'        => $this->status,
            'rating'        => $this->average_rating,
            'views'         => $this->when($allInfo, $this->views),
            'created_at'    => $this->when($allInfo, $this->created_at),
            'updated_at'    => $this->when($allInfo, $this->updated_at),
            'links'         => [
                'self' => route('services.show', $this->id),
            ],
            'category'      => CategoryResource::make($this->whenLoaded('category')),
            'freelancer'    => UserResource::make($this->whenLoaded('freelancer')),
            'reviews'       => ReviewCollection::collection($this->when($request->get('reviews') == 'true', $this->whenLoaded('reviews'))),
            'orders_count'  => empty($this->orders) ? 0 : $this->orders->count(),
            'reviews_count' => empty($this->reviews) ? 0 : $this->reviews->count(),
        ];
    }
}
