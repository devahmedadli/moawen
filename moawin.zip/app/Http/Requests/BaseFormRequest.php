<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;
use App\Traits\ApiResponse;

abstract class BaseFormRequest extends FormRequest
{
    use ApiResponse;

    /**
     * Handle a failed validation attempt.
     */
    protected function failedValidation(Validator $validator)
    {
        
        throw new HttpResponseException(
            $this->error(
                "فشل التحقق من البيانات",
                422,
                $validator->errors()
            )
        );
    }

    /**
     * Handle a failed authorization attempt.
     */
    protected function failedAuthorization()
    {
        throw new HttpResponseException(
            $this->forbidden(
                'برجاء التأكد من صلاحيات الحساب',
                ['reason' => 'insufficient_permissions'],
                403,
            )
        );
    }

    /**
     * Get custom attributes for validator errors.
     * This ensures consistent attribute names across requests
     */
    public function attributes(): array
    {
        return [
            'email'         => 'البريد الإلكتروني',
            'password'      => 'الرقم السري',
            // Add common attributes here
        ];
    }

    /**
     * Prepare the data for validation.
     * This helps sanitize input before validation
     */
    protected function prepareForValidation()
    {
        $this->merge([
            'email'     => strtolower($this->email ?? ''),
            'password'  => $this->password ?? '',
        ]);
    }
}
