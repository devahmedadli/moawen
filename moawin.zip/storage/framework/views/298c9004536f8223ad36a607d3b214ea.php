<?php if($authenticated): ?><?php $__env->startComponent('scribe::components.badges.base', ['colour' => "darkred", 'text' => 'requires authentication']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\Freelancing\2024\moawin\resources\views/vendor/scribe/components/badges/auth.blade.php ENDPATH**/ ?>